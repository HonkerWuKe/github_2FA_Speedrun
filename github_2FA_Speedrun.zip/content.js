function getAuthData() {
  try {
    // 获取手动设置码
    const setupCode = document.querySelector('.two-factor-secret')?.textContent?.trim();
    
    // 获取用户名
    const username = document.querySelector('meta[name="user-login"]')?.getAttribute('content');
    
    if (!setupCode) {
      return { error: '未找到2FA密钥，请确保在正确的设置页面' };
    }

    return {
      secret: setupCode,
      username,
      timestamp: new Date().toISOString()
    };
  } catch (error) {
    return { error: error.message };
  }
}

// 生成TOTP代码
function generateTOTP(secret) {
  const period = 30; // TOTP更新周期（秒）
  const digits = 6;  // TOTP代码长度
  
  // 获取当前时间戳（秒）
  const now = Math.floor(Date.now() / 1000);
  
  // 计算当前时间周期
  const counter = Math.floor(now / period);
  
  // 返回剩余秒数和计数器
  return {
    counter: counter,
    remainingSeconds: period - (now % period)
  };
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'getAuthData') {
    const data = getAuthData();
    if (!data.error) {
      const totp = generateTOTP(data.secret);
      data.totp = totp;
    }
    sendResponse(data);
  }
  return true;
}); 