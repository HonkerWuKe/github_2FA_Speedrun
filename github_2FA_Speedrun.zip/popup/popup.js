let totpGenerator = null;
let updateInterval = null;
let recoveryCodes = [];

document.addEventListener('DOMContentLoaded', () => {
  const error = document.getElementById('error');
  const content = document.getElementById('content');
  const secretInput = document.getElementById('secretInput');
  const startGenButton = document.getElementById('startGen');
  const totpCodeElement = document.getElementById('totpCode');
  const timerElement = document.getElementById('timer');
  
  // 恢复码相关元素
  const importRecoveryButton = document.getElementById('importRecovery');
  const showRecoveryButton = document.getElementById('showRecovery');
  const recoveryFileInput = document.getElementById('recoveryFile');
  const recoveryCodesDiv = document.getElementById('recoveryCodes');
  const codesListDiv = recoveryCodesDiv.querySelector('.codes-list');

  startGenButton.addEventListener('click', async () => {
    try {
      const secret = secretInput.value.trim();
      
      if (!secret) {
        throw new Error('请输入密钥');
      }

      // 清除之前的定时器
      if (updateInterval) {
        clearInterval(updateInterval);
      }
      
      // 初始化TOTP生成器
      totpGenerator = new TOTPGenerator(secret);
      
      // 更新TOTP代码的函数
      async function updateTOTP() {
        const { code, remainingSeconds } = await totpGenerator.generateTOTP();
        totpCodeElement.textContent = code;
        timerElement.textContent = `${remainingSeconds}秒后更新`;
        
        if (remainingSeconds === 30) {
          totpCodeElement.classList.add('new-code');
          setTimeout(() => totpCodeElement.classList.remove('new-code'), 1000);
        }
      }

      // 立即更新一次TOTP
      await updateTOTP();
      
      // 每秒更新倒计时
      updateInterval = setInterval(updateTOTP, 1000);

      content.style.display = 'block';
      error.style.display = 'none';

    } catch (err) {
      error.textContent = err.message;
      error.style.display = 'block';
      content.style.display = 'none';
    }
  });

  // 导入恢复码
  importRecoveryButton.addEventListener('click', () => {
    recoveryFileInput.click();
  });

  recoveryFileInput.addEventListener('change', async (event) => {
    try {
      const file = event.target.files[0];
      if (!file) return;

      const text = await file.text();
      recoveryCodes = text.split('\n')
        .map(line => line.trim())
        .filter(line => line && line.length > 0);

      if (recoveryCodes.length === 0) {
        throw new Error('未找到有效的恢复码');
      }

      // 保存到本地存储
      chrome.storage.local.set({ recoveryCodes }, () => {
        showRecoveryButton.style.display = 'block';
        error.style.display = 'none';
      });

    } catch (err) {
      error.textContent = '导入恢复码失败: ' + err.message;
      error.style.display = 'block';
    }
    
    // 清除文件输入，允许重新选择同一文件
    recoveryFileInput.value = '';
  });

  // 显示/隐藏恢复码
  showRecoveryButton.addEventListener('click', () => {
    const isVisible = recoveryCodesDiv.style.display === 'block';
    
    if (isVisible) {
      recoveryCodesDiv.style.display = 'none';
      showRecoveryButton.textContent = '查看恢复码';
    } else {
      // 显示恢复码
      chrome.storage.local.get(['recoveryCodes'], (result) => {
        if (result.recoveryCodes && result.recoveryCodes.length > 0) {
          codesListDiv.innerHTML = result.recoveryCodes
            .map(code => `<div class="recovery-code">${code}</div>`)
            .join('');
          recoveryCodesDiv.style.display = 'block';
          showRecoveryButton.textContent = '隐藏恢复码';
        }
      });
    }
  });

  // 加载时检查是否有保存的恢复码
  chrome.storage.local.get(['recoveryCodes'], (result) => {
    if (result.recoveryCodes && result.recoveryCodes.length > 0) {
      recoveryCodes = result.recoveryCodes;
      showRecoveryButton.style.display = 'block';
    }
  });
}); 