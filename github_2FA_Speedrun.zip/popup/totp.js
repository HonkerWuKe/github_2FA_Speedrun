// TOTP生成器
class TOTPGenerator {
  constructor(secret) {
    this.secret = secret;
    this.period = 30; // 30秒更新一次
  }

  // Base32解码
  static base32ToBytes(base32) {
    const base32chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
    let bits = '';
    
    for (let i = 0; i < base32.length; i++) {
      const val = base32chars.indexOf(base32.charAt(i).toUpperCase());
      if (val === -1) continue;
      bits += val.toString(2).padStart(5, '0');
    }

    const bytes = new Uint8Array(Math.floor(bits.length / 8));
    for (let i = 0; i < bytes.length; i++) {
      bytes[i] = parseInt(bits.substr(i * 8, 8), 2);
    }
    
    return bytes;
  }

  // 生成HMAC
  async generateHMAC(counter) {
    const key = TOTPGenerator.base32ToBytes(this.secret);
    const data = new Uint8Array(8);
    for (let i = 7; i >= 0; i--) {
      data[i] = counter & 0xff;
      counter = counter >> 8;
    }

    const hmacKey = await crypto.subtle.importKey(
      'raw',
      key,
      { name: 'HMAC', hash: 'SHA-1' },
      false,
      ['sign']
    );

    const hmac = await crypto.subtle.sign('HMAC', hmacKey, data);
    return new Uint8Array(hmac);
  }

  // 生成TOTP代码
  async generateTOTP() {
    const now = Math.floor(Date.now() / 1000);
    const counter = Math.floor(now / this.period);
    const hmac = await this.generateHMAC(counter);
    
    const offset = hmac[hmac.length - 1] & 0xf;
    const code = ((hmac[offset] & 0x7f) << 24) |
                ((hmac[offset + 1] & 0xff) << 16) |
                ((hmac[offset + 2] & 0xff) << 8) |
                (hmac[offset + 3] & 0xff);
    
    return {
      code: (code % 1000000).toString().padStart(6, '0'),
      remainingSeconds: this.period - (now % this.period)
    };
  }
} 